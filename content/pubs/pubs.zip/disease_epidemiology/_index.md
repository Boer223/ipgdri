---
# Title, summary, and page position.
linktitle: Disease epidemiology
summary: 
weight: 7
icon: book
icon_pack: fas

# Page metadata.
title: Disease epidemiology
date: '2022-12-01'
type: book # Do not modify.
---

- 169.	余琦, 周必文, 周乐聪, 刘胜毅. 1994a. 油菜生育期与菌核病感染的关系. 中国油料 (17):43–45.
- 170.	余琦, 周必文, 周乐聪, 刘胜毅. 1994b. 油菜菌核病田间菌源数量对病害的影响. 中国油料 (17):52.
- 171.	周必文, 余琦, 周乐聪, 刘胜毅. 1994. 油菜长势对菌核病的影响. 中国油料 (17):53–54.
- 172.	油菜菌核病综防课题组. 1994a. 油菜菌核病长期预测 I.可控因素作用估计. 中国油料 (17):31–33.
- 173.	油菜菌核病综防课题组. 1994b. 油菜菌核病长期预测 I.自然因素作用估计. 中国油料 (17):34–36.

