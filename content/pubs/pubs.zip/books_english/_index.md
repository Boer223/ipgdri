---
# Title, summary, and page position.
linktitle: Books in English
summary: 
weight: 1
icon: book
icon_pack: fas

# Page metadata.
title: Books in English
date: '2022-12-01'
type: book # Do not modify.
---

- 1.	Shengyi Liu, Rod Snowdon, and Chitta Kole. 2021. The Brassica Oleracea Genome. Springer.
- 2.	Shengyi Liu, Rod Snowdon, and Boulos Chalhoub. 2018. The Brassica Napus Genome. Springer.
- 3.	Shengyi Liu, Guoqing Li, and Junbin Huang. 2007. Proceedings of the 12th International Rapeseed Congress Vol IV Plant Protection. Monmouth Junction, NJ 08852, USA.: Science Press USA Inc.

