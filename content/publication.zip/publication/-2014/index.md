---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 油菜病虫害
subtitle: ''
summary: ''
authors:
- liushengyi
- 宝成 胡
tags: []
categories: []
date: '2014-12-01'
lastmod: 2022-08-19T18:27:54+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:27:54.748615Z'
publication_types:
- '6'
abstract: ''
publication: '*中国农作物病虫害*'
---
