---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Comparative genotype reactions to Sclerotinia sclerotiorum within breeding
  populations of Brassica napus and B. juncea from India and China
subtitle: ''
summary: ''
authors:
- M. J. Barbetti
- S. K. Banga
- T. D. Fu
- Y. C. Li
- D. Singh
- S. Y. Liu
- X. T. Ge
- S. S. Banga
tags: []
categories: []
date: '2014-01-01'
lastmod: 2022-08-19T18:45:26+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:26.731157Z'
publication_types:
- '2'
abstract: ''
publication: '*Euphytica*'
---
