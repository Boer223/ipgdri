---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Sources of resistance to Sclerotinia sclerotiorum in Brassica napus and B.
  juncea germplasm for China and Australia
subtitle: ''
summary: ''
authors:
- Caixia Li
- Hua Li
- Krishnapillai Sivasithamparam
- Tingdong Fu
- Yunchang Li
- Shengyi LIU
- Martin Barbetti
tags: []
categories: []
date: '2007-01-01'
lastmod: 2022-08-19T18:45:28+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:28.557537Z'
publication_types:
- '1'
abstract: ''
publication: '*12th International Rape Seed Congress, Wuhan*'
---
