---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Expressions of Defense Genes of Salicylic Acid-Dependent Signal Pathway in
  Oxalate Oxidase Transgenic Oilseed Rape （Brassica napus L.）
subtitle: ''
summary: ''
authors:
- Ruiqin Ji
- Xiangbai Dong
- Hui Feng
- Rongcun Gao
- liuyueying
- liushengyi
tags: []
categories: []
date: '2009-01-01'
lastmod: 2022-08-19T18:45:41+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:41.900084Z'
publication_types:
- '2'
abstract: Expressions of three defense genes（PR-1,GLU and CHI） of salicylic acid（SA）-dependent
  signaling pathway were measured by RT-PCR in transgenic oilseed rape（Brassica napus）
  lines and wild plants.The results showed that the three genes were all up-regulated
  expressed in transgenic lines,which indicated that the mechanism of enhanced resistance
  to Sclerotinia sclerotiorum of transgenic lines was related to the induction of
  SA-dependent signaling pathway.
publication: '*Plant Physiology Communications*'
doi: 10.13592/j.cnki.ppj.2009.07.015
---
