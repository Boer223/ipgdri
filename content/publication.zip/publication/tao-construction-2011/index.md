---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Construction of a normalized full-length cDNA library of sesame developing
  seed by DSN and SMART™
subtitle: ''
summary: ''
authors:
- K. E. Tao
- Cai-hua DONG
- M. A. O. Han
- Ying-zhong ZHAO
- Hong-yan LIU
- Sheng-yi LIU
tags: []
categories: []
date: '2011-01-01'
lastmod: 2022-08-19T18:46:19+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:46:19.694142Z'
publication_types:
- '2'
abstract: ''
publication: '*Agricultural Sciences in China*'
---
