---
# Documentation: https://wowchemy.com/docs/managing-content/

title: EST-based in silico identification and in vitro test of antimicrobial peptides
  in Brassica napus
subtitle: ''
summary: ''
authors:
- Tao Ke
- Huihui Cao
- huangjunyan
- Fan Hu
- Jin Huang
- Caihua Dong
- Xiangdong Ma
- Jingyin Yu
- Han Mao
- Xi Wang
tags: []
categories: []
date: '2015-01-01'
lastmod: 2022-08-19T18:45:26+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:26.438265Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC genomics*'
---
