---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 核盘菌菌丝生长和产草酸的营养和环境条件研究
subtitle: ''
summary: ''
authors:
- liushengyi
- 必文 周
tags: []
categories: []
date: '1993-01-01'
lastmod: 2022-08-19T18:27:57+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:27:57.653437Z'
publication_types:
- '2'
abstract: ''
publication: '*微生物学通报*'
---
