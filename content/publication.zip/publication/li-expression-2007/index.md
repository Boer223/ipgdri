---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Expression and relationships of resistance to white rust (Albugo candida) at
  cotyledonary, seedling, and flowering stages in Brassica juncea germplasm from Australia,
  China, and India
subtitle: ''
summary: ''
authors:
- C. X. Li
- Krishnapillai Sivasithamparam
- G. Walton
- P. Salisbury
- W. Burton
- Surinder S. Banga
- Shashi Banga
- C. Chattopadhyay
- A. Kumar
- R. Singh
tags: []
categories: []
date: '2007-01-01'
lastmod: 2022-08-19T18:45:28+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:28.843024Z'
publication_types:
- '2'
abstract: ''
publication: '*Australian Journal of Agricultural Research*'
---
