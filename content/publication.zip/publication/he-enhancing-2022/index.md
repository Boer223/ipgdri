---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Enhancing canola breeding by editing a glucosinolate transporter gene lacking
  natural variation
subtitle: ''
summary: ''
authors:
- heyizhou
- Zhiquan Yang
- Minqiang Tang
- Qing-Yong Yang
- zhangyuanyuan
- liushengyi
tags:
- Brassica napus
- Alleles
- Plant Breeding
- Glucosinolates
- Gene Editing
categories: []
date: '2022-03-01'
lastmod: 2022-08-19T18:45:25+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:25.313801Z'
publication_types:
- '2'
abstract: ''
publication: '*Plant Physiology*'
doi: 10.1093/plphys/kiac021
---
