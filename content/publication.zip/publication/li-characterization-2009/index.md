---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Characterization of resistance to Sclerotinia sclerotiorum among progenies
  of intergeneric hybrid between Brassica napus and Sinapis alba
subtitle: ''
summary: ''
authors:
- Aimin Li
- Yongtai ZHANG
- Jinjin Jiang
- liushengyi
- Youping Wang
tags: []
categories: []
date: '2009-01-01'
lastmod: 2022-08-19T18:45:41+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:45:40.951331Z'
publication_types:
- '2'
abstract: The resistance of twenty-four progeny lines,derived from the hybrid between
  Brassica napus and Sinapis alba,to Sclerotinia sclerotiorum was tested through inoculation
  of stem and detached leaves with mycelia of the pathogen.No significant difference
  was found between eleven progeny lines and resistant variety Zhongshuang No.9,other
  four lines showed significantly stronger resistance.This study demonstrated the
  disease resistance of intergeneric hybrid progenies can be increased significantly,it
  can play an important role in disease resistance breeding.
publication: '*Chinese Journal of Oil Crop Sciences*'
---
