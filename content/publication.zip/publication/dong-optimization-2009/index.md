---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Optimization of high quality total protein extraction and two-dimensional gel
  electrophoresis system for different Brassica napus organs
subtitle: ''
summary: ''
authors:
- Caihua Dong
- Haiheng Liu
- Shengwu Hu
- liushengyi
- huangjunyan
tags: []
categories: []
date: '2009-01-01'
lastmod: 2022-08-19T18:46:11+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:46:10.928994Z'
publication_types:
- '2'
abstract: Proteins from buds anthers and leaves were extracted using TCA(trich looaceticacid)-acetone
  method frm sterile and fertile plants of Brassica napusLdam inant GMS (genic male
  sterile) line Shaan-GMs Optinized factors inchuded extraction paranetersypes of
  IPG strip focusing procedure gel concen tration and loading quantity of samples.High
  quality2-DEmap with low background was obtained using the following optinized procedure:dissolving
  proteins with lysis sohution (7mol/L Urea 2mol/L Thoure 4% CHAPS 65mmol DTT 0.5%IPG
  buffer pH 3~10 or pH 4~7,10mL.Camplete Protease Inh ib itor Coctail Tab lets for
  each sample), load ing 150ug protein sample isoelectric focusing with IEFⅡ procedure
  (30v,12h; 200v, h; 500v, 1h; 1 000v, 0.5h; 10 000V,2h;10 000V,8h),SDS-PAGEwith 10%
  gel concentrationand finally detecting proteins using silvertaining method.The optin
  ized system will be able to facilitate the proteam ics research on B.napus
publication: '*Chinese Journal of Oil Crop Sciences*'
---
