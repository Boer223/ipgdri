---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Identification of genome-wide single nucleotide polymorphisms in allopolyploid
  crop Brassica napus
subtitle: ''
summary: ''
authors:
- Shunmou Huang
- Linbin Deng
- Mei Guan
- Jiana Li
- Kun Lu
- Hanzhong Wang
- Donghui Fu
- Annaliese S. Mason
- liushengyi
- Wei Hua
tags: []
categories: []
date: '2013-01-01'
lastmod: 2022-08-19T18:46:19+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:46:18.924552Z'
publication_types:
- '2'
abstract: ''
publication: '*BMC genomics*'
---
