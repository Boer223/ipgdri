---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 2013～2014年度国家冬油菜品种区域试验菌核病抗性鉴定总结报告
subtitle: ''
summary: ''
authors:
- ' 中国农业科学院油料作物研究所农业部油料作物生物学重点实验室油菜病害与抗病性课题组'
- liushengyi
tags: []
categories: []
date: '2014-07-01'
lastmod: 2022-08-19T18:27:56+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:27:56.053820Z'
publication_types:
- '6'
abstract: ''
publication: '*中国冬油菜新品种动态：2013-2014年度国家冬油菜品种区域试验汇总报告*'
---
