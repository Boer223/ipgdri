---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Modelling of gene loss propensity in the pangenomes of three Brassica species
  suggests different mechanisms between polyploids and diploids
subtitle: ''
summary: ''
authors:
- Philipp E. Bayer
- Armin Scheben
- Agnieszka A. Golicz
- Yuxuan Yuan
- Sebastien Faure
- HueyTyng Lee
- Harmeet Singh Chawla
- Robyn Anderson
- Ian Bancroft
- Harsh Raman
tags: []
categories: []
date: '2021-01-01'
lastmod: 2022-08-19T18:46:16+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:46:16.885908Z'
publication_types:
- '2'
abstract: ''
publication: '*Plant biotechnology journal*'
---
