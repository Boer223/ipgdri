---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Bioinformatics analysis and functional annotation of complete expressed sequence
  tag collection for oil crops
subtitle: ''
summary: ''
authors:
- Tao Ke
- Han Mao
- Fengli Hui
- Caihua Dong
- Guohua Chai
- liushengyi
tags: []
categories: []
date: '2020-01-01'
lastmod: 2022-08-19T18:46:11+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:46:11.022290Z'
publication_types:
- '2'
abstract: This is the first report of a systematic study of genes expressed by means
  of expressed sequence tag (EST) analysis in oil crops.A total of 1, 185, 911 EST
  sequences were thus obtained fram GenBank C huster analysis enab led the iden tification
  of contigs and singletons which resulted as 289, 892 UniEST sequences Putative functions
  were assigned to about average 60.6% of these non redundant UniESTs.From th is gene
  function annotation resources we screened the genes which are related to the oil
  synthesis metabolic pathway and constructed the compared me tabolic pathway network
  of these eight oil crops.This EST infomation exploration work reconstructed the
  potentialm etabolic network fram public EST sequences resource carried out visualization
  and exploration of highly camplex genanic levelmetabolic networksand can acce lera
  te the use ofEST data for studying and comparing the difference of seed oil content
  between this common oil crops.
publication: '*China Journal of Bioinformatics*'
---
