---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Proceedings of the 12th International Rapeseed Congress Vol IV Plant Protection
subtitle: ''
summary: ''
authors:
- liushengyi
- Guoqing Li
- Junbin Huang
tags: []
categories: []
date: '2007-01-01'
lastmod: 2022-08-19T18:44:56+08:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2022-08-19T10:44:56.628237Z'
publication_types:
- '5'
abstract: ''
publication: '*Science Press USA Inc*'
---
